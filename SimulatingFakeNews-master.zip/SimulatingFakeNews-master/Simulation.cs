﻿using Microsoft.Data.Analysis;
using ModelAttemptWPF;
using System;
using System.Collections.Generic;
using System.Text;

public class Simulation
{
    public double runSpeed = 1;
    public string versionName;
    public int nRuns;
    public int runNumber=1;

    public int time=0;
    public int IDCount = 0;

    public List<Person> humanPopulation=new List<Person>();
    private List<string> nameList = new List<string>() {
            "aakash", "aamir", "aaron", "abbas", "abby", "abdul", "abdullah", "abe", "abel", "abhay", "abhijeet", "abhijit", "abhilash", "abhinav", "abhishek", "abigail", "abraham", "abu", "ace", "ada", "adam", "adarsh", "adeel", "adel", "adi", "adil", "aditi", "aditya", "adnan", "adolfo", "adrian", "adriana", "adriano", "adrienne", "agnes", "agnieszka", "ahmad", "ahmed", "ahmet", "ahsan", "aida", "aidan", "aileen", "aimee", "aisha", "aj", "ajay", "ajit", "akash", "akhil", "akshay", "al", "alaa", "alain", "alan", "alana", "albert", "alberto", "aldo", "ale", "alec", "alejandra", "alejandro", "aleksandra", "alessandra", "alessandro", "alex", "alexa", "alexander", "alexandr", "alexandra", "alexandre", "alexandria", "alexandru", "alexey", "alexis", "alfonso", "alfred", "alfredo", "ali", "alice", "alicia", "alina", "aline", "alireza", "alisa", "alisha", "alison", "alissa", "alistair", "allan", "allen", "allie", "allison", "ally", "allyson", "alma", "alok", "alvaro", "alvin", "alyssa", "amal", "aman", "amanda", "amar", "amber", "amelia", "american", "ami", "amie", "amin", "amina", "amine", "amir", "amit", "amol", "amos", "amr", "amy", "ana", "anand", "anas", "anastasia", "anders", "anderson", "andi", "andre", "andrea", "andreas", "andreea", "andrei", "andres", "andrew", "andrey", "andré", "andrés", "andy", "angel", "angela", "angelica", "angelina", "angelo", "angie", "angus", "anh", "ani", "anil", "anish", "anita", "anjali", "ankit", "ankita", "ankur", "ann", "anna", "anne", "annette","anni", "annie", "anoop", "anshul", "anthony", "antoine", "antoinette", "anton", "antonia", "antonio", "antony", "antónio", "anu", "anuj", "anup", "anurag", "anwar", "anya", "apple", "april", "archie", "ari", "ariel", "arif", "arjun", "arlene", "armand", "armando", "arnaud", "arnold", "arpit", "arshad", "art", "artem", "arthur", "artur", "arturo", "arun", "arvind", "asad", "ash", "asha", "asher", "ashish", "ashleigh", "ashley", "ashok", "ashraf", "ashton", "ashutosh", "ashwin", "asif", "asim", "astrid", "athena", "atif", "atul", "aubrey", "audrey", "augusto", "aurora", "austin", "autumn", "ava", "avery", "avi", "avinash", "axel", "ayesha", "ayman", "ayush", "aziz", "bailey", "bala", "balaji", "barb", "barbara", "barney", "baron", "barry", "bart", "basil", "beatrice", "beatriz", "beau", "becca", "becky", "bee", "belinda", "bella", "ben", "benedict", "benjamin", "benny", "benoit", "benson", "bernadette", "bernard", "bernardo", "bernie", "bert", "best", "beth", "bethany", "betsy", "betty", "bev", "beverly", "bhanu", "bharat", "bianca", "big", "bilal", "bill", "billie", "billy", "bjorn", "black", "blaine", "blair", "blake", "blanca", "blue", "bob", "bobbi", "bobbie", "bobby", "bogdan", "bonnie", "boris", "boyd", "brad", "bradford", "bradley", "brady", "brandi", "brandon", "brandy", "brenda", "brendan", "brendon", "brent", "bret", "brett", "brian", "brianna", "bridget", "bright", "brigitte", "britt", "brittany", "brittney", "brock", "brooke", "bruce", "bruno", "bryan", "bryant", "bryce", "buck", "bud", "butch", "byron", "caio", "caitlin", "cal", "caleb", "calvin", "cam", "cameron", "camila", "camilla", "camille", "camilo", "candace", "candice", "candy", "captain", "cara", "carey", "cari", "carina", "carl", "carla", "carlo", "carlos", "carlton", "carly", "carmen", "carol", "carole", "carolina", "caroline", "carolyn", "carrie", "carson", "carter", "cary", "caryn", "casey", "cassandra", "cassie", "catalina", "catherine", "cathy", "cecil", "cecilia", "cedric", "celeste", "celia", "cesar", "chad", "chaitanya", "chan", "chance", "chandan", "chandler", "chandra", "chantal", "charity", "charlene", "charles", "charley", "charlie", "charlotte", "charmaine", "chas", "chase", "chaz", "chelsea", "chen", "cheri", "cherie", "cherry", "cheryl", "chester", "chet", "chetan", "chi", "chiara", "chip", "chirag", "chloe", "chris", "chrissy", "christa", "christi", "christian", "christie", "christina", "christine", "christoph", "christophe", "christopher", "christy", "chuck", "cindi", "cindy", "cj", "claire", "clara", "clare", "clarence", "clark", "claude", "claudia", "claudio", "clay", "clayton", "clement", "cliff", "clifford", "clifton", "clint", "clinton", "clive", "clyde", "cody", "cole", "colette", "colin", "colleen", "collin", "collins", "connie", "connor", "conor", "conrad", "constance", "cora", "corey", "corinne", "cory", "courtney", "craig", "cris", "cristian", "cristiano", "cristina", "crystal", "curt", "curtis", "cyndi", "cynthia", "cyril", "cyrus", "césar", "daisy", "dakota", "dale", "dalia", "dallas", "dalton", "damian", "damien", "damon", "dan", "dana", "dane", "dani", "daniel", "daniela", "daniele", "daniella", "danielle", "danilo", "danish", "danny", "dante", "daphne", "dara", "darcy", "daren", "daria", "darin", "dario", "darius", "darla", "darlene", "darrel", "darrell", "darren", "darrin", "darryl", "darshan", "darwin", "daryl", "dave", "david", "davide", "davis", "dawn", "dean", "deanna", "deb", "debbie", "debby", "debi", "deborah", "debra", "dee", "deep", "deepa", "deepak", "deirdre", "dejan", "delia", "delores", "dena", "denis", "denise", "dennis", "denny", "derek", "derrick", "desiree", "desmond", "destiny", "devendra", "devin", "devon", "dexter", "dheeraj", "dhiraj", "dhruv", "diana", "diane", "dianna", "dianne", "dick", "diego", "dilip", "dillon", "dima", "dimitri", "dimitris", "dina", "dinesh", "dino", "diogo", "dion", "dirk", "divya", "dmitri", "dmitriy", "dmitry", "dolly", "dolores", "dom", "dominic", "dominick", "dominique", "don", "donald", "donna", "donnie", "donny", "donovan", "dora", "doreen", "dorian", "doris", "dorothy", "doug", "douglas", "drake", "drew", "duane", "duke", "duncan", "dustin", "dusty", "dwayne", "dwight", "dylan", "earl", "ed", "eddie", "eddy", "edgar", "edith", "edmond", "edmund", "edna", "edson", "eduard", "eduardo", "edward", "edwin", "ehsan", "eileen", "ekaterina", "el", "elaine", "eleanor", "elena", "eleni", "eli", "elias", "elie", "elijah", "elisa", "elisabeth", "elise", "elisha", "eliza", "elizabeth", "ella", "elle", "ellen", "ellie", "elliot", "elliott", "elmer", "elsa", "elsie", "elvis", "emanuel", "emeka", "emil", "emilia", "emilie", "emilio", "emily", "emma", "emmanuel", "enrico", "enrique", "eric", "erica", "erich", "erick", "ericka", "erik", "erika", "erin", "ernest", "ernesto", "ernie", "errol", "erwin", "esteban", "esther", "ethan", "etienne", "eugene", "eunice", "eva", "evan", "evans", "eve", "evelyn", "everett", "ezra", "fabian", "fabien", "fabio", "fadi", "fahad", "faisal", "faith", "farah", "farhan", "farid", "fatima", "faye", "federico", "felicia", "felipe", "felix", "fernanda", "fernando", "filip", "filipe", "fiona", "flavio", "flora", "florence", "florian", "floyd", "forbes", "forrest", "fran", "frances", "francesca", "francesco", "francine", "francis", "francisco", "franco", "francois", "frank", "frankie", "franklin", "franz", "fred", "freddie", "freddy", "frederic", "frederick", "fredrick", "fredrik", "fritz", "gabby", "gabe", "gabriel", "gabriela", "gabriele", "gabriella", "gabrielle", "gaby", "gail", "gale", "galina", "ganesh", "gareth", "garrett", "garry", "gary", "gaurav", "gautam", "gavin", "gayle", "gemma", "gene", "genevieve", "geo", "geoff", "geoffrey", "george", "georges", "georgia", "georgina", "gerald", "geraldine", "gerard", "gerardo", "geri", "german", "gerry", "gideon", "gigi", "gil", "gilbert", "gilberto", "gilles", "gillian", "gina", "ginger", "ginny", "gino", "gio", "giorgi", "giorgio", "giovanni", "girish", "gisele", "giuseppe", "gladys", "glen", "glenda", "glenn", "gloria", "godfrey", "godwin", "gonzalo", "gopal", "goran", "gordon", "govind", "grace", "graeme", "graham", "grant", "green", "greg", "gregg", "gregory", "greta", "gretchen", "guido", "guilherme", "guillaume", "guillermo", "gus", "gustavo", "gwen", "gwendolyn", "hadi", "hai", "hal", "haley", "hamid", "hamza", "han", "hana", "hani", "hank", "hanna", "hannah", "hans", "happy", "hardik", "hari", "haris", "harish", "harley", "harold", "harriet", "harris", "harrison", "harry", "harsh", "harsha", "harvey", "hasan", "hassan", "hayden", "hayley", "hazel", "heath", "heather", "hector", "heidi", "helen", "helena", "helene", "hemant", "henri", "henrik", "henrique", "henry", "herb", "herbert", "herman", "hilary", "hillary", "himanshu", "hitesh", "hoang", "holly", "hong", "hope", "howard", "hubert", "hugh", "hugo", "humberto", "hung", "hunter", "hussain", "hussein", "huy", "héctor", "iain", "ian", "ibrahim", "ida", "ignacio", "igor", "ike", "ilona", "ilya", "iman", "imran", "ina", "inga", "ingrid", "inna", "ioana", "ira", "irena", "irene", "irfan", "irina", "iris", "irma", "irving", "isaac", "isabel", "isabella", "isabelle", "isaiah", "ismael", "ismail", "israel", "ivan", "ivana", "ivo", "ivy", "jack", "jacki", "jackie", "jackson", "jacky", "jaclyn", "jacob", "jacqueline", "jacquelyn", "jacques", "jacqui", "jacquie", "jade", "jae", "jai", "jaime", "jake", "jakob", "jakub", "jamal", "james", "jami", "jamie", "jamil", "jan", "jana", "jane", "janelle", "janet", "janette", "janice", "janie", "janine", "janis", "jared", "jarrett", "jarrod", "jasmin", "jasmine", "jason", "jasper", "jatin", "javier", "jay", "jayne", "jayson", "jc", "jd", "jean", "jeanette", "jeanie", "jeanine", "jeanne", "jeannette", "jeannie", "jed", "jeff", "jefferson", "jeffery", "jeffrey", "jelena", "jen", "jenifer", "jenn", "jenna", "jenni", "jennie", "jennifer", "jenny", "jens", "jeremiah", "jeremy", "jeri", "jeroen", "jerome", "jerry", "jesper", "jess", "jesse", "jessica", "jessie", "jesus", "jhon", "jill", "jillian", "jim", "jimmie", "jimmy", "jin", "jing", "jitendra", "jo", "joan", "joana", "joann", "joanna", "joanne", "joao", "joaquin", "jocelyn", "jodi", "jodie", "jody", "joe", "joel", "joelle", "joey", "johan", "johann", "johanna", "john", "johnathan", "johnnie", "johnny", "johnson", "jojo", "jon", "jonah", "jonas", "jonathan", "jonathon", "joni", "jonny", "jordan", "jordi", "jorge", "jose", "josef", "joseph", "josephine", "josh", "joshua", "josie", "josue", "josé", "joy", "joyce", "joão", "jp", "jr", "juan", "juanita", "jude", "judi", "judith", "judy", "jules", "julia", "julian", "juliana", "julie", "julien", "juliet", "julio", "julius", "jun", "junaid", "june", "junior", "just", "justin", "justine", "jyoti", "kai", "kaitlyn", "kamal", "kamil", "kamran", "kapil", "kara", "karan", "kareem", "karen", "kari", "karim", "karin", "karina", "karl", "karla", "karolina", "karthik", "kartik", "karyn", "kasey", "kashif", "kasia", "kat", "katarina", "kate", "katelyn", "katerina", "katharine", "katherine", "kathi", "kathie", "kathleen", "kathryn", "kathy", "katia", "katie", "katrina", "katy", "katya", "kaushik", "kay", "kayla", "kc", "keisha", "keith", "kelley", "kelli", "kellie", "kelly", "kelsey", "kelvin", "ken", "kendall", "kendra", "kennedy", "kenneth", "kenny", "kent", "keri", "kerri", "kerry", "ketan", "kevin", "khaled", "khalid", "kieran", "kim", "kimberley", "kimberly", "king", "kingsley", "kira", "kiran", "kirk", "kirsten", "kishore", "kit", "kitty", "klaus", "kofi", "konstantin", "kris", "krishna", "krista", "kristen", "kristi", "kristian", "kristie", "kristin", "kristina", "kristine", "kristy", "krystal", "krzysztof", "kumar", "kunal", "kurt", "kwame", "kyle", "kylie", "la", "lacey", "lady", "lakshmi", "lalit", "lana", "lance", "lane", "lara", "larissa", "larry", "lars", "laura", "laurel", "lauren", "laurence", "laurent", "lauri", "laurie", "lawrence", "le", "lea", "leah", "leandro", "leanne", "lee", "lei", "leigh", "leila", "leland", "len", "lena", "lenny", "leo", "leon", "leonard", "leonardo", "leroy", "lesley", "leslie", "lester", "leticia", "levi", "lewis", "lex", "li", "lia", "liam", "libby", "lidia", "lilian", "liliana", "lillian", "lilly", "lily", "lim", "lin", "lina", "lincoln", "linda", "lindsay", "lindsey", "linh", "lionel", "lisa", "lise", "little", "liz", "liza", "lizzie", "lloyd", "logan", "lois", "lokesh", "lola", "long", "lonnie", "lora", "lord", "loren", "lorena", "lorenzo", "loretta", "lori", "lorna", "lorraine", "lou", "louie", "louis", "louisa", "louise", "lourdes", "love", "lowell", "lu", "luc", "luca", "lucas", "lucia", "luciana", "luciano", "lucky", "lucy", "luigi", "luis", "luisa", "luiz", "lukas", "luke", "luz", "luís", "lydia", "lyle", "lyn", "lynda", "lynette", "lynn", "lynne", "ma", "mac", "mack", "madeline", "madhav", "madison", "magda", "magdalena", "maggie", "magnus", "mahendra", "mahesh", "mahmoud", "mai", "maja", "malcolm", "malik", "mallory", "mandy", "mani", "manish", "manisha", "manny", "manoj", "manu", "manuel", "manuela", "mara", "marc", "marcel", "marcela", "marcelo", "marci", "marcia", "marcie", "marcin", "marcio", "marco", "marcos", "marcus", "marcy", "marek", "margaret", "margarita", "margie", "margo", "mari", "maria", "mariah", "mariam", "marian", "mariana", "marianna", "marianne", "mariano", "marie", "marilyn", "marina", "mario", "marion", "marisa", "marisol", "marissa", "maritza", "marius", "marjorie", "mark", "marko", "markus", "marla", "marlene", "marlon", "marsha", "marshall", "marta", "martha", "marti", "martin", "martina", "marty", "marvin", "mary", "maryam", "maryann", "maría", "mason", "massimo", "mat", "matheus", "mathew", "mathieu", "matt", "matteo", "matthew", "matthias", "maura", "maureen", "maurice", "mauricio", "mauro", "max", "maxim", "maxine", "maxwell", "may", "maya", "mayank", "mayra", "mayur", "md", "md.", "meagan", "meg", "megan", "megha", "meghan", "mehdi", "mehmet", "mehul", "mel", "melanie", "melinda", "melissa", "melody", "melvin", "mercedes", "meredith", "mia", "micah", "michael", "michaela", "michal", "micheal", "michel", "michele", "michelle", "mick", "mickey", "miguel", "mihaela", "mihai", "mikael", "mike", "mikey", "mikhail", "miki", "mila", "milan", "milena", "miles", "millie", "milos", "milton", "mimi", "min", "mina", "mindy", "ming", "minh", "mir", "mira", "miranda", "miriam", "miss", "missy", "mister", "misty", "mitch", "mitchell", "mj", "mo", "moe", "mohamad", "mohamed", "mohammad", "mohammed", "mohan", "mohd", "mohit", "mohsin", "moises", "molly", "mona", "monica", "monika", "monique", "morgan", "morris", "morten", "moses", "moshe", "mostafa", "muhammad", "muhammed", "mukesh", "murali", "murat", "murray", "musa", "mustafa", "mustapha", "my", "myles", "myra", "myron", "nabil", "nadeem", "nadia", "nadine", "nana", "nancy", "naomi", "narendra", "naresh", "nasir", "nat", "natalia", "natalie", "natasha", "nate", "nathalie", "nathan", "nathaniel", "naveed", "naveen", "navin", "neal", "ned", "neeraj", "neha", "neil", "nelly", "nelson", "neo", "nestor", "new", "ng", "nguyen", "nic", "nicholas", "nichole", "nick", "nicki", "nicky", "nico", "nicola", "nicolas", "nicole", "nidhi", "niels", "nigel", "nik", "nikhil", "niki", "nikita", "nikki", "nikola", "nikolay", "nikos", "nilesh", "nina", "nino", "niraj", "nirmal", "nisha", "nishant", "nita", "nitesh", "nitin", "noah", "noel", "noelle", "nolan", "noor", "nora", "norm", "norma", "norman", "not", "nuno", "nur", "oksana", "ola", "old", "oleg", "olga", "oliver", "olivia", "olivier", "omar", "omer", "orlando", "osama", "oscar", "osman", "osvaldo", "otto", "owen", "pablo", "paco", "paige", "pam", "pamela", "pankaj", "paola", "paolo", "parker", "parth", "pascal", "pastor", "pat", "patrice", "patricia", "patrick", "patsy", "patti", "patty", "paul", "paula", "paulette", "paulina", "pauline", "paulo", "pavan", "pavel", "pawan", "pearl", "pedro", "peggy", "penelope", "penny", "per", "perry", "pete", "peter", "petr", "petra", "phil", "philip", "philippe", "phillip", "phoebe", "phoenix", "phuong", "phyllis", "pia", "pierre", "pieter", "piotr", "piyush", "pj", "polly", "pooja", "poonam", "pradeep", "prakash", "pramod", "pranav", "prasad", "prasanna", "prashant", "prashanth", "prateek", "pratik", "praveen", "pravin", "precious", "preeti", "prem", "preston", "prince", "princess", "priscilla", "priya", "priyanka", "puneet", "quang", "quentin", "quinn", "rachael", "rachel", "rachelle", "radu", "rae", "rafael", "raghu", "rahul", "rainer", "raj", "raja", "rajan", "rajat", "rajeev", "rajendra", "rajesh", "rajiv", "raju", "rakesh", "ralph", "ram", "rama", "raman", "ramesh", "rami", "ramiro", "ramon", "ramona", "rana", "randal", "randall", "randi", "randolph", "randy", "ranjeet", "raphael", "raquel", "rashid", "rashmi", "raul", "raven", "ravi", "ravindra", "ray", "raymond", "real", "rebecca", "rebekah", "red", "reed", "reggie", "regina", "reginald", "reid", "rekha", "renata", "renato", "rene", "renee", "rené", "reuben", "rex", "rey", "reza", "rhonda", "ria", "ric", "ricardo", "riccardo", "rich", "richa", "richard", "richie", "rick", "ricky", "rico", "riley", "rishabh", "rishi", "rita", "ritesh", "ritu", "rizwan", "rj", "rob", "robb", "robbie", "robby", "robert", "roberta", "roberto", "robin", "robyn", "rocco", "rochelle", "rocio", "rocky", "rod", "roderick", "rodger", "rodney", "rodolfo", "rodrigo", "rogelio", "roger", "rogerio", "rohan", "rohit", "roland", "rolando", "rolf", "roman", "romeo", "ron", "ronald", "ronaldo", "ronda", "roni", "ronnie", "ronny", "rory", "rosa", "rosanne", "rosario", "rose", "rosemarie", "rosemary", "roshan", "rosie", "ross", "roxana", "roxanne", "roy", "royce", "ruben", "ruby", "rudy", "rui", "ruslan", "russ", "russell", "rusty", "ruth", "ryan", "saad", "sabina", "sabrina", "sachin", "saeed", "sagar", "sahil", "sai", "said", "saif", "sajid", "sal", "salah", "salim", "sally", "salman", "salvador", "salvatore", "sam", "samantha", "sameer", "samer", "sami", "samir", "sammy", "samson", "samuel", "san", "sana", "sandeep", "sandi", "sandip", "sandra", "sandro", "sandy", "sanjay", "sanjeev", "santhosh", "santiago", "santosh", "sara", "sarah", "sascha", "sasha", "satish", "satya", "saul", "saurabh", "saurav", "savannah", "sayed", "scot", "scott", "sean", "sebastian", "sebastien", "seema", "senthil", "serena", "serge", "sergei", "sergey", "sergio", "seth", "shah", "shahid", "shahzad", "shan", "shana", "shane", "shankar", "shanna", "shannon", "shantanu", "sharad", "shari", "sharon", "shashank", "shashi", "shaun", "shauna", "shawn", "shawna", "shay", "sheena", "sheila", "shelby", "sheldon", "shelley", "shelly", "sheri", "sherif", "sherman", "sherri", "sherrie", "sherry", "sheryl", "shirley", "shiv", "shiva", "shivam", "shoaib", "shruti", "shubham", "shweta", "shyam", "sid", "siddharth", "sidney", "silver", "silvia", "simon", "simona", "simone", "siobhan", "siva", "sky", "skyler", "smith", "sneha", "sofia", "solomon", "sonali", "sonia", "sonja", "sonny", "sonya", "sophia", "sophie", "spencer", "sri", "sridhar", "srikanth", "srinivas", "sriram", "stacey", "stacie", "stacy", "stan", "stanley", "star", "stefan", "stefanie", "stefano", "stella", "steph", "stephan", "stephane", "stephanie", "stephen", "sterling", "steve", "steven", "stewart", "stu", "stuart", "su", "sudhir", "sue", "suman", "sumit", "sunil", "sunny", "suraj", "suresh", "surya", "susan", "susana", "susanna", "susanne", "sushant", "sushil", "susie", "suzan", "suzanne", "suzi", "suzie", "suzy", "sven", "svetlana", "swapnil", "swati", "sydney", "syed", "sylvia", "sérgio", "tabitha", "tam", "tamara", "tamer", "tami", "tammie", "tammy", "tan", "tania", "tanja", "tanner", "tanya", "tara", "tarek", "tariq", "tarun", "taryn", "tasha", "tatiana", "taylor", "tech", "ted", "teddy", "tee", "tejas", "terence", "teresa", "teri", "terrance", "terrence", "terri", "terry", "tess", "tessa", "thanh", "theo", "theodore", "theresa", "therese", "thiago", "thierry", "thom", "thomas", "tia", "tiago", "tiffany", "tim", "timmy", "timothy", "tin", "tina", "tj", "tobias", "toby", "tod", "todd", "tom", "tomas", "tomasz", "tommy", "toni", "tony", "tonya", "tori", "tracey", "traci", "tracie", "tracy", "tran", "travis", "trent", "trevor", "trey", "tricia", "trina", "trish", "trisha", "tristan", "troy", "trudy", "tuan", "tushar", "tyler", "tyrone", "tyson", "uday", "uma", "umair", "umar", "umesh", "ursula", "usman", "vadim", "vaibhav", "val", "valentina", "valeria", "valerie", "van", "vanessa", "varun", "vaughn", "venkat", "venkatesh", "vera", "vernon", "veronica", "veronika", "vic", "vicente", "vicki", "vickie", "vicky", "victor", "victoria", "vijay", "vikas", "vikram", "viktor", "vinay", "vince", "vincent", "vineet", "vinicius", "vinny", "vinod", "vipin", "vipul", "virginia", "vishal", "vishnu", "vitor", "vivek", "vivian", "vlad", "vladimir", "wade", "waleed", "walid", "wallace", "wally", "walt", "walter", "wan", "wanda", "wang", "waqas", "warren", "wayne", "wei", "wendell", "wendy", "wes", "wesley", "whitney", "wil", "will", "william", "williams", "willie", "willis", "willy", "wilma", "wilson", "winnie", "winston", "wolf", "wolfgang", "wong", "wyatt", "xavier", "xiao", "yan", "yana", "yang", "yash", "yasir", "yasmin", "yasser", "yi", "ying", "yogesh", "yolanda", "yong", "young", "youssef", "yu", "yulia", "yuri", "yusuf", "yves", "yvette", "yvonne", "zac", "zach", "zachary", "zack", "zain", "zak", "zane", "zeeshan", "zoe"
        };
    private Random random = new Random();


    // whatever is being changed in each simulation run
    public int feedTimeFrame;

    public Simulation(string versionName, double runSpeed,int feedTimeFrame,int nRuns=50)
	{
        this.versionName = versionName;
        this.runSpeed = runSpeed;
        this.feedTimeFrame = feedTimeFrame;
        this.nRuns = nRuns;
	}


    public Person CreatePerson(double o, double c, double e, double a, double n, double PL, double OL)
    {
        string name = nameList[random.Next(nameList.Count)];
        Person newPerson = new Person(IDCount, name, o, c, e, a, n, PL, OL);
        IDCount++;
        humanPopulation.Add(newPerson);
        return newPerson;
    }
    public void RandomPopulate(int n)
    {
        for (int i = 0; i < n; i++)
        {
            // randomly assign OCEAN values between 0 and 1
            CreatePerson(random.NextDouble(), random.NextDouble(), random.NextDouble(), random.NextDouble(), random.NextDouble(),random.NextDouble(),random.NextDouble());
        }
    }

    public void DistributionPopulate(int n)
    {
        // Assume a normal distribution of each personality trait
        // Distribution of personality traits for the UK
        //https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4372610/
        // divided b 5 to ensure each is on a 0-1 scale
        double eMean = 3.24/5.0;//3.24
        double eStd = 0.82/5.0;//0.82
        double aMean = 3.74/5.0;
        double aStd = 0.62/5.0;
        double cMean = 3.65/5.0;
        double cStd = 0.7/5.0;
        double nMean = 2.97/5.0;
        double nStd = 0.81 / 5.0;
        double oMean = 3.67 / 5.0;
        double oStd = 0.64 / 5.0;
        for (int i = 0; i < n; i++)
        {
            // assign OCEAN values according to a normal distribution
            double OL = random.NextDouble();
           CreatePerson(NormalDistribution(oMean,oStd), NormalDistribution(cMean, cStd), NormalDistribution(eMean, eStd), NormalDistribution(aMean, aStd),
               NormalDistribution(nMean, nStd), NormalDistribution(0.5,0.4), OL);
        }
    }
    
 

    public List<double> CalculateAverages()
    {
        double o = 0; double c = 0; double e = 0; double a = 0; double n = 0;
        double onlineLiteracy = 0; double politicalLeaning = 0;
        double nPeople = Convert.ToDouble(humanPopulation.Count);
        foreach (Person person in humanPopulation)
        {
            // big 5 personality traits
            o += person.o;
            c += person.c;
            e += person.e;
            a += person.a;
            n += person.n;

            // other traits
            onlineLiteracy += person.onlineLiteracy;
            politicalLeaning += person.politicalLeaning;
        }
        o /= nPeople; c /= nPeople; e /= nPeople; a /= nPeople; n /= nPeople;
        onlineLiteracy /= nPeople; politicalLeaning /= nPeople;
        List<double> averages = new List<double>() { o, c, e, a, n, onlineLiteracy, politicalLeaning };
        return averages;
    }

    public double NormalDistribution(double mean,double std)
    {
        double randNormal=1.1;
        while (randNormal < 0 | randNormal > 1)
        {
            double u1 = 1.0 - random.NextDouble(); //uniform(0,1] random doubles
            double u2 = 1.0 - random.NextDouble();
            double randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) *
                         Math.Sin(2.0 * Math.PI * u2); //random normal(0,1)

            randNormal = mean + std * randStdNormal; //random normal(mean,stdDev^2)
        }

        return randNormal;
    }

    private void AddDistributedNews(int nFake, int nTrue, OSN osn, double meanEFake = 0.75, double meanETrue = 0.5, double meanBFake = 0.25, double meanBTrue = 0.75)
    {
        double std = 0.1;
        int nPostsPerTrue = 2;
        for (int i = 0; i < nFake; i++)
        {
            double e = NormalDistribution(meanEFake, std);
            double b = NormalDistribution(meanBFake, std);
            osn.CreateNewsRandomPoster("FakeNews", false, time, e, b);
        }
        for (int j = nFake; j < nFake + nTrue; j++)
        {
            double e = NormalDistribution(meanETrue, std);
            double b = NormalDistribution(meanBTrue, std);
            osn.CreateNewsRandomPoster("TrueNews", true, time, e, b, nPostsPerTrue);
        }
    }

}
