# SimulatingFakeNews
Msc Project "Simulating the spread of fake news in online social networks" made using c# and wpf
