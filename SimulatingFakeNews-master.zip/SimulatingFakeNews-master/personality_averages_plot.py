import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

personality_averages=pd.read_csv("C:/Users/Anni/Documents/Uni/Computer "
                                 "Science/Proj/CSVs and text files/personalityAverages.csv")
